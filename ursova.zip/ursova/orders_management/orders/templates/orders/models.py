from django.db import models
from django.contrib.auth.models import User




class Order(models.Model):
    client_name = models.CharField(max_length=100)
    product_name = models.CharField(max_length=100)
    product_quantity = models.IntegerField()
    total_price = models.FloatField()
    order_date = models.DateTimeField(auto_now_add=True)
    preorder = models.CharField(max_length=100, default='Обычный заказ')
    payment_method = models.CharField(max_length=100)
