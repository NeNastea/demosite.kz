from django.shortcuts import render, redirect
from .models import Order
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

# Временное хранилище пользователей
registered_users = {}


def korzina_view(request):
    return render(request, 'korzina.html')

def your_view_name(request):
    return render(request, 'korzina.html')

@csrf_exempt
def register(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')

        if username in registered_users:
            return JsonResponse({'error': 'Пользователь уже существует'}, status=400)

        registered_users[username] = {'email': email, 'password': password}
        return JsonResponse({'message': 'Пользователь зарегистрирован'}, status=200)

    return JsonResponse({'error': 'Неверный метод запроса'}, status=400)

@csrf_exempt
def login(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        username = data.get('username')
        password = data.get('password')

        if username in registered_users and registered_users[username]['password'] == password:
            return JsonResponse({'message': f'Добро пожаловать, {username}'}, status=200)

        return JsonResponse({'error': 'Неверные данные для входа'}, status=400)

    return JsonResponse({'error': 'Неверный метод запроса'}, status=400)



def korzina_view(request):
    return render(request, 'korzina.html')

def index(request):
    return render(request, 'orders/login.html')

def login_view(request):
    return render(request, 'orders/login.html')

def register_view(request):
    return render(request, 'orders/reg.html')

def korzina_view(request):
    return render(request, 'orders/korzina.html')

def korzina(request):
    if request.user.is_authenticated:
        orders = Order.objects.filter(client=request.user)
        orders_data = []
        for order in orders:
            order_data = {
                'clientName': order.client_name,
                'productName': order.product_name,
                'productQuantity': order.product_quantity,
                'totalPrice': order.total_price,
                'orderDate': order.order_date,
                'preorder': order.preorder,
                'paymentMethod': order.payment_method,
            }
            orders_data.append(order_data)
        return render(request, 'orders/korzina.html', {'orders': orders_data})
    else:
        return redirect('login_html')

def order_management_view(request):
    if request.method == 'POST':
        client_name = request.POST['clientName']
        product_name = request.POST['productName']
        product_quantity = request.POST['productQuantity']
        total_price = request.POST['totalPrice']
        order_date = request.POST.get('orderDate', None)
        preorder = request.POST.get('preorder', 'Обычный заказ')
        payment_method = request.POST['paymentMethod']

        order = Order.objects.create(
            client=request.user,
            client_name=client_name,
            product_name=product_name,
            product_quantity=product_quantity,
            total_price=total_price,
            order_date=order_date,
            preorder=preorder,
            payment_method=payment_method
        )
        order.save()
        return redirect('order_management')
    else:
        orders = Order.objects.all()
        return render(request, 'orders/order_management.html', {'orders': orders})
