from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('login.html', views.login_view, name='login_html'),
    path('login/', views.login_view, name='login'),
    path('reg/', views.register_view, name='register'),
    path('register', views.register, name='register'),
    path('login', views.login, name='login'),
    path('orders/order_management.html', views.order_management_view, name='order_management'),
    path('orders/korzina.html', views.korzina_view, name='korzina_html'),
]
