<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $to = 'ivan_svetlakov_apple@mail.ru';
    $subject = 'Заказы';
    $message = '';

    foreach ($data as $order) {
        $message .= 'Имя клиента: ' . $order['clientName'] . "\n";
        $message .= 'Наименование товара: ' . $order['productName'] . "\n";
        $message .= 'Количество: ' . $order['productQuantity'] . "\n";
        $message .= 'Цена: ' . $order['productPrice'] . "\n";
        $message .= 'Дата: ' . $order['orderDate'] . "\n";
        $message .= 'Предоплата (%): ' . $order['preorder'] . "\n\n";
    }

    $headers = 'From: webmaster@example.com' . "\r\n" .
               'Reply-To: webmaster@example.com' . "\r\n" .
               'X-Mailer: PHP/' . phpversion();

    if (mail($to, $subject, $message, $headers)) {
        echo 'Письмо отправлено успешно!';
    } else {
        echo 'Ошибка при отправке письма.';
    }
}
?>
